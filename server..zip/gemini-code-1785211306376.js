import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
app.use(express.static(__dirname));

// ==========================================
// [메모리 DB] 8가지 날씨 체감 데이터 저장소
// ==========================================
const weatherVotes = {
  "서울특별시": {
    "☀️ 맑음": 15, "☁️ 흐림": 5, "🌧️ 비": 2, "❄️ 눈": 0,
    "🔥 무더움/땡볕": 18, "💧 습함/꿉꿉함": 12, "🍃 바람 불어 시원": 4, "🍂 쌀쌀함/선선": 1
  },
  "경기도": {
    "☀️ 맑음": 10, "☁️ 흐림": 8, "🌧️ 비": 1, "❄️ 눈": 0,
    "🔥 무더움/땡볕": 14, "💧 습함/꿉꿉함": 10, "🍃 바람 불어 시원": 6, "🍂 쌀쌀함/선선": 2
  },
  "부산광역시": {
    "☀️ 맑음": 8, "☁️ 흐림": 3, "🌧️ 비": 0, "❄️ 눈": 0,
    "🍃 바람 불어 시원": 12, "🔥 무더움/땡볕": 5, "💧 습함/꿉꿉함": 4, "🍂 쌀쌀함/선선": 3
  }
};

// 1. 날씨 제보 등록 API
app.post('/api/vote', (req, res) => {
  const { location, weatherState } = req.body;

  if (!location || !weatherState) {
    return res.status(400).json({ error: '위치와 날씨 상태 정보가 필요합니다.' });
  }

  if (!weatherVotes[location]) {
    weatherVotes[location] = {};
  }

  weatherVotes[location][weatherState] = (weatherVotes[location][weatherState] || 0) + 1;

  res.json({ success: true, location, weatherState });
});

// 2. 지역별 날씨 % 통계 반환 API
app.get('/api/stats', (req, res) => {
  const result = {};

  for (const [region, votes] of Object.entries(weatherVotes)) {
    let total = 0;
    for (const count of Object.values(votes)) {
      total += count;
    }
    result[region] = { total, votes };
  }

  res.json(result);
});

// 3. AI 코디 추천 API (테스트용 기본 응답)
app.post('/api/generate', async (req, res) => {
  try {
    const { location, weatherState, activityType } = req.body;

    const resultData = {
      summary: `${location}은(는) 현재 '${weatherState}' 상태로 느껴지며, ${activityType} 활동을 고려해 추천해 드립니다.`,
      top: '통풍이 잘되는 반팔 티셔츠 또는 리넨 셔츠',
      bottom: '얇은 슬랙스 또는 반바지',
      shoes: '통기성이 좋은 러닝화/스니커즈',
      supplies: ['양우산', '휴대용 선풍기', '자외선 차단제'],
      tip: '수분 섭취를 자주 해주시고 날씨 변화에 유의하세요.'
    };

    res.json(resultData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 서버가 실행되었습니다: http://localhost:${PORT}`);
});